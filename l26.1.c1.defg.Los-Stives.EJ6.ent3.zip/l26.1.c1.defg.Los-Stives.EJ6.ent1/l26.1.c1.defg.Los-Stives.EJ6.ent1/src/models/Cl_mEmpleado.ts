export default class Cl_mEmpleado {
    private _monto: number = 0;
    private _tipo: string = "";
    private _persona: string = "";

    constructor({monto, tipo, persona}: {monto: number, tipo: string, persona: string} = {monto: 0, tipo: "", persona: ""}) {
        this.monto = monto;
        this.tipo = tipo;
        this.persona = persona;
    }
    set monto(monto: number) {
        this._monto = +monto;
    }
    get monto(): number {
        return this._monto;
    }
    set tipo(tipo: string) {
        this._tipo = tipo;
    }
    get tipo(): string {
        return this._tipo;
    }
    set persona(persona:string){
        this._persona = persona;
    }
    get persona() :string {
        return this._persona;
    }
}
