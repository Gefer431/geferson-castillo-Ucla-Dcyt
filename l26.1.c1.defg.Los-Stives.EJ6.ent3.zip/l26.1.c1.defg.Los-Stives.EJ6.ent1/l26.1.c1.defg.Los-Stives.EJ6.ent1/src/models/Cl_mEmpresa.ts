import Cl_mEmpleado from "./Cl_mEmpleado.js";

export default class Cl_mEmpresa {
    private acMontoObr: number;
    private acMontoAdm: number;
    private contMontoObr: number;
    private contMontoAdm: number;
    private contPersona: number;
    private contJuridico: number;
    constructor() {
        this.acMontoObr = 0;
        this.acMontoAdm = 0;
        this.contMontoObr = 0;
        this.contMontoAdm = 0;
        this.contPersona = 0;
        this.contJuridico = 0;
    }
    procesarPersonal(a: Cl_mEmpleado): void {
        if(a.tipo=='obrero') {
            this.acMontoObr += a.monto;
            this.contMontoObr++;
        }
        if(a.tipo=='administrativo') {
            this.acMontoAdm += a.monto;
            this.contMontoAdm++;
        }
        if(a.persona=='j') {
            this.contJuridico++;
            this.contPersona++;
        } else if(a.persona=='n') {
            this.contPersona++;
        } else if (a.persona=='e') {
            this.contPersona++;
        }
        

    }
    montoObr() {
        return this.acMontoObr;
    }
    montoAdm() {
        return this.acMontoAdm;
    }
    promedioMontObr() {
        return this.acMontoObr/this.contMontoObr;
    }
    promedioMontAdm() {
        return this.acMontoAdm/this.contMontoAdm;
    }
    porcentajeJuridicos(){
        return this.contJuridico/this.contPersona*100;
    }
}
